from google.cloud import storage as gcs
from datetime import datetime
from GoogleCloudStorage import GoogleCloudStorage
import base64
import pandas as pd
import datetime as dt

def process_data(data_df,data_ant_df,client_df,product_df,ubigeo_df):

    data_df = data_df.merge(client_df,how="inner",on="IDCliente")
    product_df = product_df.drop_duplicates()

    data_df = data_df.merge(product_df,how="inner",on="IDProducto")

    data_df = data_df.merge(ubigeo_df,how="left",on="Parroquia")

    data_df = data_df[["IDProducto","Row ID","Order ID","Fecha","FechaEnviio","ModoEnvio","IDCliente","Cliente","Segmento","Categoria","SubCategoria","Producto","Ventas","Cantidad","Descuento","Margen","Provincia","Canton","Parroquia","ZONA"]]

    data_df = pd.concat([data_df, data_ant_df], ignore_index=True)

    data_df["ANIO"] = pd.DatetimeIndex(data_df['Fecha']).year
    data_df["MES"] = pd.DatetimeIndex(data_df['Fecha']).month
    data_df["Periodo"] = data_df["Fecha"].to_numpy().astype('datetime64[M]')

    return data_df

def main(event=None, context=None):
    """Triggered from a message on a Cloud Pub/Sub topic.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """
    pubsub_message = base64.b64decode(event['data']).decode('utf-8')
    print(pubsub_message)

    client_filename = "01_raw/ClientesF.csv"
    product_filename = "01_raw/ProductosF.csv"
    ubigeo_filename = "01_raw/ubigeo.csv"
    data_filename = "01_raw/Datos_2019-2020.xlsx"
    data_ant_filename = "01_raw/Datos_antiguosF.xlsx"

    client_gcs = gcs.Client()

    data_blob = GoogleCloudStorage(client_gcs, "prediqt-pe-gcs", data_filename)
    data_bytes = data_blob.download_to_bytesio()
    data_df = pd.read_excel(data_bytes)

    data_ant_blob = GoogleCloudStorage(client_gcs, "prediqt-pe-gcs", data_ant_filename)
    data_bytes = data_ant_blob.download_to_bytesio()
    data_ant_df = pd.read_excel(data_bytes)

    client_blob = GoogleCloudStorage(client_gcs, "prediqt-pe-gcs", client_filename)
    client_bytes = client_blob.download_to_bytesio()
    client_df = pd.read_csv(client_bytes,encoding = "ISO-8859-1")

    product_blob = GoogleCloudStorage(client_gcs, "prediqt-pe-gcs", product_filename)
    product_bytes = product_blob.download_to_bytesio()
    product_df = pd.read_csv(product_bytes,encoding = "ISO-8859-1")

    ubigeo_blob = GoogleCloudStorage(client_gcs, "prediqt-pe-gcs", ubigeo_filename)
    ubigeo_bytes = ubigeo_blob.download_to_bytesio()
    ubigeo_df = pd.read_csv(ubigeo_bytes,encoding = "ISO-8859-1")

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')    
    bucket.blob('02_intermediate/cliente.csv').upload_from_string(client_df.to_csv(index=False), 'text/csv')

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')    
    bucket.blob('02_intermediate/producto.csv').upload_from_string(product_df.to_csv(index=False), 'text/csv')

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')
    bucket.blob('02_intermediate/ubigeo.csv').upload_from_string(ubigeo_df.to_csv(index=False), 'text/csv')

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')    
    bucket.blob('02_intermediate/data_2019_2020.csv').upload_from_string(data_df.to_csv(index=False), 'text/csv')

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')    
    bucket.blob('02_intermediate/data_antigua.csv').upload_from_string(data_ant_df.to_csv(index=False), 'text/csv')

    result = process_data(data_df,data_ant_df,client_df,product_df,ubigeo_df)

    bucket = client_gcs.get_bucket('prediqt-pe-gcs')  
    bucket.blob('03_report/ABC.csv').upload_from_string(result.to_csv(index=False), 'text/csv')

